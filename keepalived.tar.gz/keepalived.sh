#!/bin/bash
# set -x
install(){
   yum install openssl openssl-devel -y
   tar -zxvf keepalived-1.2.15.tar.gz
   cd keepalived-1.2.15
   ./configure --prefix=/usr/local/keepalived && make && make install
   cp /usr/local/keepalived/etc/rc.d/init.d/keepalived /etc/rc.d/init.d/
   cp /usr/local/keepalived/etc/sysconfig/keepalived /etc/sysconfig/
   mkdir /etc/keepalived
   cp /usr/local/keepalived/etc/keepalived/keepalived.conf /etc/keepalived/
   cp /usr/local/keepalived/sbin/keepalived /usr/sbin/
   chkconfig --add keepalived
   chkconfig keepalived on
   #vim /etc/keepalived/keepalived.conf 
}
config(){
  echo "" > /etc/keepalived/keepalived.conf
  cat >> /etc/keepalived/keepalived.conf <<EOF
global_defs {

    router_id jr-198-www

}

vrrp_instance VI_1 {

   state SLAVE

   nopreempt 

   interface eth0

   virtual_router_id 174 #vip的末位

   priority  150 #优先级

   advert_int 3

   authentication {

        auth_type PASS

        auth_pass 5566   

   }

   virtual_ipaddress {

        192.168.31.13/24 dev eth0 scope global label eth0:1

        }
   }
EOF
  }
main(){

install
config
}
main
